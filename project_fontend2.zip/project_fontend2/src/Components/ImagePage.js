import React, { Component} from 'react';

class ImagePage extends Component {
    render() {
        return (
            <div id="carouselExampleIndicators" className="carousel slide my-4" data-ride="carousel">
            <ol className="carousel-indicators">
              <li data-target="#carouselExampleIndicators" data-slide-to={0}  />
              <li data-target="#carouselExampleIndicators" data-slide-to={1} className="active" />
              <li data-target="#carouselExampleIndicators" data-slide-to={2}  />
            </ol>
            <div className="carousel-inner" role="listbox">
              <div className="carousel-item">
                <img className="d-block img-fluid" src="https://images-na.ssl-images-amazon.com/images/I/81MA4uU1gWL._AC_SL1500_.jpg?fbclid=IwAR3vhp684sckN1PUjhygZGdVz6r-r77LxYSNGevYda2I-aTjASG-iapJznQ" alt="First slide" />
              </div>
              <div className="carousel-item active">
                <img className="d-block img-fluid" src="https://znews-photo.zadn.vn/w1200/Uploaded/neg_estpyge/2019_11_14/4480501_MV_Agusta_Brutale_1000_Serie_Oro.jpg" alt="Second slide" />
              </div>
              <div className="carousel-item">
                <img className="d-block img-fluid" src="https://znews-photo.zadn.vn/w1200/Uploaded/neg_estpyge/2019_11_14/1_Street_Triple_RS.jpg" alt="Third slide" />
              </div>
            </div>
            <a className="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
              <span className="carousel-control-prev-icon" aria-hidden="true" />
              <span className="sr-only">Previous</span>
            </a>
            <a className="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
              <span className="carousel-control-next-icon" aria-hidden="true" />
              <span className="sr-only">Next</span>
            </a>
          </div>
        );
    }
}

export default ImagePage;