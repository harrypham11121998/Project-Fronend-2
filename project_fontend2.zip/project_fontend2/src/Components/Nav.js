import React, { Component } from 'react';
import {
  Link,
} from "react-router-dom";
class Nav extends Component {
    render() {
        return (
            <nav className="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
            <div className="container">
              <Link to="/home" className="navbar-brand" > <img className=" img-fluid logo" src="https://www.bikurye.com.tr/wp-content/uploads/2019/01/1_149906.jpg" alt="First slide"/></Link>
              <div className="collapse navbar-collapse" id="navbarResponsive">
                <ul className="navbar-nav ml-auto">
                <div className="nameShop">CAR STORE MOTOCYCLE</div>
                  <li className="nav-item">
                    <Link to="/login" className="nav-link" >Logout</Link>
                  </li>
                </ul>
              </div>
            </div>
          </nav>          
        );
    }
}

export default Nav;