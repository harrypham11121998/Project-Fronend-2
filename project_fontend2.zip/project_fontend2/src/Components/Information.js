import React, { Component } from 'react';

class Information extends Component {
    render() {
        return (
            <div className="row contact">
                <div className="col-md footer-below">
                    <div className="contact"> Contact </div>
                    <div className="info">
                        <p> <i className="fa fa-map-marker" aria-hidden="true"></i> 53 Võ Văn Ngân, P.Linh Chiểu, Q.Thủ Đức, TP.HCM</p>
                        <p><i className="fa fa-phone-square" aria-hidden="true"></i> 0969.699.799</p>
                    </div>
                </div>
                <div className="col-md footer-below">
                    <div className="contact "> Connect </div>
                    <div className="facebook">
                    <a href="https://www.facebook.com/ATF365"><i className="fa fa-facebook-square" aria-hidden="true"></i> Facebook</a>
                    </div>
                </div>
                <div className="col-md footer-below">
                    <div className="contact"> Payment Method </div>
                    <div className="card-pay">
                    <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcRY82RFNO3VI8JN0X67KOAE0ohw2INnPvfK1w&usqp=CAU" alt=""/>
                    <img src="https://f1.pngfuel.com/png/28/420/953/visa-mastercard-logo-bank-icon-card-icon-credit-icon-debit-icon-mastercard-icon-zanskar-brand-png-clip-art.png" alt=""/>
                    <img src="https://img.favpng.com/14/9/7/business-icon-id-card-icon-pass-icon-png-favpng-j7BFTRM9h7HCg5PCyxmSDJAdx.jpg" alt=""/>
                    </div>
                </div>
            </div>
        );
    }
}

export default Information;