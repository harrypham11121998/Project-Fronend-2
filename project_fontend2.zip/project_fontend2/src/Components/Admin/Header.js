import React, { Component } from 'react';

export default class componentName extends Component {
  render() {
    return (
            <div className="container text-center"> 
                <h1 className="display-3">Admin Manager</h1>
            </div>
    );
  }
}
